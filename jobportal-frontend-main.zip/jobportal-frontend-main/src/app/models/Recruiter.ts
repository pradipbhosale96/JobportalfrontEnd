export class Recruiter {

   
    name: any;
    username: any;
    email: any;
    password: any;
    website: any;
    company: any;
    address: any;
    phone: any;

    

    constructor(
        name: any,
        username: any,
        email: any,
        website: any,
        company: any,
        address: any,
        phone: any) {

            this.name=name;
            this.address=address;
            this.company=company;
            this.email=email;
            this.phone=phone;
            this.website=website;
            this.username=username;

    }
}