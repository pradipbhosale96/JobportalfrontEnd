export class jobSeekerLogin
{
    usernameOrEmail:any;
    password:any;


    constructor(usernameOrEmail:any ,password:any)
    {
        this.usernameOrEmail=usernameOrEmail;
        this.password=password;

    }
}