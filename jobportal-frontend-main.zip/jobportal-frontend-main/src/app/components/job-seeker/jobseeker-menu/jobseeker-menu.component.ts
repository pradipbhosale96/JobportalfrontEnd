import { Component } from '@angular/core';

@Component({
  selector: 'app-jobseeker-menu',
  templateUrl: './jobseeker-menu.component.html',
  styleUrls: ['./jobseeker-menu.component.css']
})
export class JobseekerMenuComponent {

}
