import { Component } from '@angular/core';

@Component({
  selector: 'app-recruiter-logo',
  templateUrl: './recruiter-logo.component.html',
  styleUrls: ['./recruiter-logo.component.css']
})
export class RecruiterLogoComponent {

}
